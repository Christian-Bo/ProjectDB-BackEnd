package com.nexttechstore.nexttech_backend.exception;

// exception/BadRequestException.java

public class BadRequestException extends RuntimeException {
    public BadRequestException(String msg){ super(msg); }
}

